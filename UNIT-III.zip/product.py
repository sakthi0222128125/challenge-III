def linearsearchproduct(productlist,targetproduct):
  indices=[]
  for index,product in enumerate(productlist):
     if product==targetproduct:
        indices.append(index)
  return indices
  #example usages
products=["shoes","boot","loafer","shoes","sandle","shoes"]
target="shoes"
result=linearsearchproduct(products,target)
print(result)